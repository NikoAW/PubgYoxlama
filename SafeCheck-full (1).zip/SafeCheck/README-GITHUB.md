# GitHub quraşdırması

1. Repo yarat, bu qovluğu push et (`git init && git add . && git commit -m init && git push`).
2. Settings → Secrets and variables → Actions → New secret:
   - `GOOGLE_SERVICES_JSON` — Firebase Console → Project settings → Android app → google-services.json məzmunu
   - `FIREBASE_SERVICE_ACCOUNT` — Project settings → Service accounts → Generate new private key (JSON məzmunu)
3. Firebase Console → Authentication → Google aktiv et; Android app əlavə et (paket: `com.nbdev.safecheck`), SHA-1 əlavə et.
4. Actions tab: `Android APK` işləyəndə APK Artifacts-dan yüklənir; `Firebase Deploy` hosting + rules + functions yükləyir.
5. Service account-a rollar: Firebase Admin, Cloud Functions Admin, Service Account User.
6. Release APK üçün: keystore-u base64 edib secret kimi əlavə et (`KEYSTORE_B64`, `KEY_ALIAS`, `KEY_PASS`) və workflow-a `assembleRelease` addımı əlavə et.
