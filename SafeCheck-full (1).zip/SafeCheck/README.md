# SafeCheck

| Qovluq | Nə edir |
|---|---|
| `web/` | Veb panel (index.html = istifadəçi, admin.html = admin) — Firebase Hosting |
| `web/js/firebase.js` | Firebase bağlantısı + callable köməkçisi |
| `web/js/auth.js` | Google giriş |
| `web/js/app.js` | Ana səhifə, planlar, dashboard, nəticə səhifəsi |
| `web/js/risk-engine.js` | Bal cədvəli (Functions-dakı `risk.js` ilə eynidir) |
| `web/js/analysis.js` | Lokal qaydalı analiz mətni |
| `firebase/database.rules.json` | Realtime Database qaydaları |
| `firebase/functions/index.js` | Server məntiqi: kod yaratma, atomik qoşulma, nəticə, admin |
| `android/` | Kotlin tətbiq (kod daxiletmə, cihaz yoxlaması, nəticə göndərmə) |
| `.github/workflows/` | APK build + Firebase deploy |

## Quraşdırma
1. Firebase Console: Authentication → Google aktiv; Realtime Database yarat; **Blaze plan** (Functions + scheduler üçün).
2. Authorized domains-ə hosting domenini əlavə et.
3. İlk admin: Database-də `admins/<sənin-UID>: true` əl ilə yaz (Auth → Users-dən UID).
4. GitHub secrets: `GOOGLE_SERVICES_JSON`, `FIREBASE_SERVICE_ACCOUNT` (bax `README-GITHUB.md`).
5. `main`-ə push → Actions APK və deploy edir.

## İcazələr
- `INTERNET` — nəticəni serverə göndərmək üçün. Başqa icazə yoxdur.
- `<queries>` — yalnız siyahıdakı konkret paketlərin quraşdırılıb-quraşdırılmadığı.

## Məlum məhdudiyyətlər
Bax: layihə çatdırılma qeydləri (PUBG qovluq yoxlaması, Play Integrity, FCM token, Business müqayisə hələ yoxdur).
